$(document).ready(function () 
{
	$("body").click(function () 
		{
			$("#recover_pass").hide(400);
		});
		
	$("#rec_pass").click(function () 
		{
			var off=$(this).offset();
			$("#recover_pass").css({top:off.top,left:off.left});
			$("#recover_pass").show(200);
		return false;
		});
});


function login_submit()
{
	$.ajax({type:'POST', url: 'php/index.php',dataType : "json", data:"login="+$("#login").val()+
																						"&pass="+hex_md5($("#pass").val()), success: 
	 	 	function(response) 
	 	 			{
	 	 				if (response.url!="error") 
	 	 					{
	 	 					window.location = response.url;
	 	 					}
	 	 				else 
	 	 					{
	 	 						var err_div = $("<div id=\"err\">Ой, неправильное имя или пароль</div>");
	 	 						$("#main").append(err_div);
	 	 					}                  
	 	 			}
	 	 	});
	return false;
};
