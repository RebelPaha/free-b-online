<?
        $server_name='localhost';
	$server_account='eurostyl_site';
	$server_password='tTrZozSD(&2,';
	$sql_base='eurostyl_site';
	$server_mail = "";
	$to_mail = "";
	$redirect_to ="/a";
	$tmp_path = "/home/eurostyl/public_html/img"
?>