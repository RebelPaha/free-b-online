<?
$merchant_id='i8349114177';
$signature="XFXBKtVRGNKlyappjJUylZGjHFwDQ2zBCK2VH3J";
$url="https://www.liqpay.com/?do=clickNbuy";
$method='card';
$phone='+20123145121';

	$xml="<request>      
		<version>1.2</version>
		<result_url>http://mysite.com/lqanswer.php</result_url>
		<server_url>http://mysite.com/lqanswer.php</server_url>
		<merchant_id>$merchant_id</merchant_id>
		<order_id>ORDER_1234</order_id>
		<amount>10</amount>
		<currency>USD</currency>
		<description>Description</description>
		<default_phone>$phone</default_phone>
		<pay_way>$method</pay_way> 
		</request>
		";
	
	
	$xml_encoded = base64_encode($xml); 
	$lqsignature = base64_encode(sha1($signature.$xml.$signature,1));
	


echo("<form action='$url' method='POST'>
      <input type='hidden' name='operation_xml' value='$xml_encoded' />
      <input type='hidden' name='signature' value='$lqsignature' />
	<input type='submit' value='Pay'/>
	</form>");
?>
	
