#include "../header/regex.h"



typedef struct {
char* out_link;
int out_link_len;
} out_link;


typedef struct {
    char* meta_description;
    int meta_description_len;
    char* meta_keywords;
    int meta_keywords_len;
    char* title;
    int title_len;
    char* in_link;
    int in_link_len;
    int err;
    out_link* out_links;
    int out_links_len;
}url_parse;


int url_parsing(url_parse *ans);
void url_parse_free(url_parse * ans);
void url_parse_init(url_parse *ans);

uint write_cb(char *in, uint size, uint nmemb, TidyBuffer *out);


