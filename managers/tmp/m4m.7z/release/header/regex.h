#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <regex.h>


int regex_replace (char *buf, int size, char *res, char rp);
int regex_match(char* buf,int size,char* res);
