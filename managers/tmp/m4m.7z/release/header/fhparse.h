#include "../header/regex.h"

typedef struct {
    char* filename;
    int filename_len;
    char* filtered_filename;
    int filtered_filename_len;
    char* ext_filename;
    int ext_filename_len;
    char* filesize;
    int filesize_len;
    char* fh_title;
    int fh_title_len;
    int err;
    char* in_link;
    int in_link_len;
}fhost_parse;

int url_ent(char* url, int url_len);
int query_filehost(fhost_parse *ans);
void free_query_filehost(fhost_parse * ans);
void fhost_parse_init(fhost_parse *ans);
uint write_cb(char *in, uint size, uint nmemb, TidyBuffer *out);


