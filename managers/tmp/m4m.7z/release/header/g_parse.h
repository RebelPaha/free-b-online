

typedef struct 
{
char *title;
int title_len;
char* description;
int description_len;
char *link;
int link_len;
}
google_ans;

typedef struct 
{
google_ans* gans;
int gans_len;

char* in_url;
int in_url_len;

int err;
} google_parse;

int google_parsing(google_parse *ans);
void google_parse_init(google_parse* ans);
void google_parse_free(google_parse * ans);

