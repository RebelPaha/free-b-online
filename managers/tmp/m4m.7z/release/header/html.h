
uint write_cb(char *in, uint size, uint nmemb, TidyBuffer *out);
char* html_ent(char* buf,int buf_len);
int url_ent(char* url, int url_len);
int curl_get(char* in_link,TidyDoc *tdoc,TidyBuffer *docbuf, TidyBuffer *tidy_errbuf);
