#include "../header/regex.h"

char* host_analyze(char *filehost,int in_url_len);
