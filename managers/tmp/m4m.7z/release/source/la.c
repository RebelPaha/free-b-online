#include <stdio.h>
#include <tidy/tidy.h>
#include <tidy/buffio.h>
#include <curl/curl.h>

#include "../header/html.h"
#include "../header/la.h"

/*
uint write_cb(char *in, uint size, uint nmemb, TidyBuffer *out)
{
  uint r;
  r = size * nmemb;
  tidyBufAppend( out, in, r );
  return(r);
}
*/
//поддерживаем градусс неадеквата
uint cnt=0;
char* links[10];

 
void extract_links(TidyDoc doc, TidyNode tnod,char* uhost,int uhost_len)
{
TidyNode child;
 
  for ( child = tidyGetChild(tnod); child; child = tidyGetNext(child) )
  {
    ctmbstr name = tidyNodeGetName( child );
    if ( name )
	{
	TidyAttr attr;
        if(!strncmp(name,"div",3))   // find <div class="s"> aka description
	    {
	    for ( attr=tidyAttrFirst(child); attr; attr=tidyAttrNext(attr) ) 
	        {
	        if((!strncmp(tidyAttrName(attr),"class",5))&&(!strncmp(tidyAttrValue(attr),"s",1))) 
		    {
		    TidyNode span;
		    for ( span = tidyGetChild(child); span; span = tidyGetNext(span) )
		        {
			if(!strncmp(tidyNodeGetName(span),"span",4))		//extract span
			    {
			    TidyBuffer buf;
    			    tidyBufInit(&buf);

    			    tidyNodeGetText(doc, span, &buf);
			    if(buf.size)
				{
				char* tmp = malloc(buf.size+1);
				strncpy(tmp,(char*)buf.bp,buf.size);
				tmp[buf.size]=0;
				int tmp_len = 0;

				char* hostname=malloc(uhost_len+15);
				int hostname_len = uhost_len;

				sprintf(hostname,"http://%s/[a-z]*",uhost);
				hostname_len = strlen(hostname);
				hostname[hostname_len]=0;
				
				tmp_len = regex_replace (tmp,buf.size, "<[^>]*>",0x7f);
				if((tmp_len =regex_match(tmp,tmp_len,hostname))!=0)	//где то здесь он что то не может очистить
				    {
				    //printf("[tmp] %s\n",tmp);
				    tmp[tmp_len]=0;
				    links[cnt]=malloc(tmp_len+1); //<-- may rewrite//спорно
				    strncpy(links[cnt],tmp,tmp_len);
				    links[cnt][tmp_len]=0;
				    }
				else
				    {
				    links[cnt] = malloc(3);
				    strncpy(links[cnt]," \0",2);
				    }

				free(hostname);
				free(tmp);
				tmp = NULL;
				hostname = NULL;
				cnt++;
				}
			    tidyBufFree(&buf);
			    
			    }
			}
		    }
		}
	    }
	}
    extract_links( doc, child,uhost,uhost_len ); /* recursive */ 
  }
}
uint oout=0;

void find_search_div_la(TidyDoc doc, TidyNode tnod,char* uhost,int uhost_len)
{
  TidyNode child;
  for ( child = tidyGetChild(tnod); child; child = tidyGetNext(child) )
  {
    ctmbstr name = tidyNodeGetName( child );
    if ( name )
    {
	if(!strncmp(name,"div",2))
	    {
	    TidyAttr attr;
    	    for (attr=tidyAttrFirst(child); attr; attr=tidyAttrNext(attr) ) 
		{
		if(!strncmp(tidyAttrValue(attr),"ires",4))
		    {
		    extract_links(doc,child,uhost,uhost_len);
		    int i;
		    uint out[10]={0};
		    for(i=0;i!=cnt;i++)
		        {
		        int j;
		        for(j=0;j!=cnt;j++)
			    {
			    int i_len = 0;
				i_len = strlen(links[i]); 
			    int j_len = 0;
				j_len = strlen(links[j]);
			    if(i_len==j_len)
				if(!strncmp(links[i],links[j],i_len))
	    			    out[i]++;
			    }
			}
			for(i=0;i!=cnt;i++)
			    if(out[i]>out[oout])
				oout=i;
		    }
    		}
	    }
    }
    find_search_div_la(doc, child,uhost,uhost_len); /* recursive */ 
  }
}
 
 
char* host_analyze(char *filehost, int in_url_len)
{
TidyDoc tdoc;
cnt=0;
TidyBuffer docbuf = {0};
TidyBuffer tidy_errbuf = {0};
int err;
char *in_url=malloc(in_url_len+100);
sprintf(in_url,"https://www.google.com.ua/search?q=allintext:http://%s/+lol",filehost);

err = curl_get(in_url,&tdoc,&docbuf,&tidy_errbuf);

if ( !err ) 
    {
    err = tidyParseBuffer(tdoc, &docbuf); /* parse the input */ 
    if ( err >= 0 ) 
	{
        err = tidyCleanAndRepair(tdoc); /* fix any problems */ 
        if ( err >= 0 ) 
	    {
             err = tidyRunDiagnostics(tdoc); /* load tidy error buffer */ 
            if ( err >= 0 ) 
		{
		find_search_div_la( tdoc, tidyGetRoot(tdoc),filehost, in_url_len); /* walk the tree */ 
        	}
    	    }
        }
    }

tidyBufFree(&docbuf);
tidyBufFree(&tidy_errbuf);
tidyRelease(tdoc);

//printf("Most used %s \n",links[oout]);

if(!err)
    return 0;
else 
    return links[oout];
}

/*
int main(void)
{
char* in_url = "depositfiles.com";
int out_url_len = strlen(in_url);
char* out_url = malloc(out_url_len+1);

strncpy(out_url,in_url,out_url_len);
out_url[out_url_len]=0;
printf("%s",host_analyze(out_url,out_url_len));
return 0;
}
*/