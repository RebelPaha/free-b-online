#include <stdio.h>
#include <tidy/tidy.h>
#include <tidy/buffio.h>
#include <curl/curl.h>
#include "../header/regex.h"
#include "../header/html.h"
#include "../header/url_parse.h"

#define fout stdout
#define attr_name tidyAttrName(attr)
#define attr_val tidyAttrValue(attr)
#define attr_val_len strlen(attr_val)

//fhost_parse ans;

int ex_content(TidyNode child, char* out)
{
TidyAttr attr;
int len=0;
for (attr=tidyAttrFirst(child); attr; attr=tidyAttrNext(attr) ) 
    {
    if((attr_name)&&(attr_val))
	{
	if(!strncasecmp(attr_name,"content",7))
	    {
	    len = attr_val_len;
	    if(out!=NULL)
		strncpy(out,attr_val,len);
	    }
	}
    }
return len;
}


void  url_query(TidyDoc doc, TidyNode tnod,url_parse* ans)
{
TidyNode child;
  for ( child = tidyGetChild(tnod); child; child = tidyGetNext(child) )
  {
    ctmbstr name = tidyNodeGetName( child );
    if ( name )
    {
///*-------------------------------- start parsing meta -------------------------------------
//    if(!strncmp(name,"title",5))
      if(tidyNodeIsTITLE(child))
        {
	TidyBuffer buf;
	tidyBufInit(&buf);
        tidyNodeGetText(doc, child, &buf);
	if(buf.size)
	    {
	    char* tmp = malloc(buf.size+1);
	    strncpy(tmp,(char*)buf.bp,buf.size);
	    tmp[buf.size]=0;
	    int tmp_len = 0;
	    tmp_len = regex_replace(tmp,buf.size,"<[^>]*>",0x7f);
	    tmp = html_ent(tmp,tmp_len);
	   tmp_len = strlen(tmp);
	    //-----------------
	    ans->title = malloc(tmp_len+1);
	    strncpy(ans->title,tmp,tmp_len);
	    ans->title[tmp_len]=0;
	    ans->title_len = tmp_len;
	    //------------------
	    free(tmp);
	    tmp = NULL;
	    }
	tidyBufFree(&buf);
        }
    if(tidyNodeIsMETA(child))
        {
	TidyAttr attr;
	for (attr=tidyAttrFirst(child); attr; attr=tidyAttrNext(attr) ) 
    	    {
    	    if((attr_name)&&(attr_val))
		{
		if((!strncasecmp(attr_name,"name",4))&&(!strncasecmp(attr_val,"Keywords",8)))
		    {
		    int cont_len =0;
		    if((cont_len = ex_content(child,NULL))!=0)
			{
			ans->meta_keywords = malloc(cont_len+1);
			ans->meta_keywords_len = ex_content(child,ans->meta_keywords);
			ans->meta_keywords[cont_len]=0;
			}
		    }
		    if((!strncasecmp(attr_name,"name",4))&&(!strncasecmp(attr_val,"Description",8)))
		    {
		    int cont_len =0;
		    if((cont_len = ex_content(child,NULL))!=0)
			{
			ans->meta_description = malloc(cont_len+1);
			ans->meta_description_len = ex_content(child,ans->meta_description);
			ans->meta_description[cont_len]=0;
			}
		    }
    		}
	    }
	}
//------------------------------------- end parsing meta --------------------------------------------*/;
///*----------------------------------- parsing all <a> --------------------------------------------;
    if(tidyNodeIsA(child))
	{
//	printf("[a]\n");
	TidyAttr attr;
	for (attr=tidyAttrFirst(child); attr; attr=tidyAttrNext(attr) ) 
    	    {
    	    if((attr_name)&&(attr_val))
		{
		if(!strncmp(attr_name,"href",4))
		    {
		    out_link ol;
		    //there might be checking to regexp

		    ol.out_link  = malloc(attr_val_len+1);
		    ol.out_link_len = attr_val_len;
		    strncpy(ol.out_link, attr_val,ol.out_link_len);
		    ol.out_link[ol.out_link_len]=0;
		    
		    ans->out_links =  realloc(ans->out_links,((ans->out_links_len+1)*sizeof(out_link)));		    
		    ans->out_links[ans->out_links_len] = ol;

		    ans->out_links_len+=1;
		    }
		}
	    }
	}
//------------------------------------end parsing <a> ----------------------------------------------*/;
///*-----------------------------------start parsing body ----------------
    if(tidyNodeIsBODY(child))
	{
	TidyBuffer buf;
	tidyBufInit(&buf);
        tidyNodeGetText(doc, child, &buf);
	if(buf.size)
	    {
	    char* tmp = malloc(buf.size+1);
	    strncpy(tmp,(char*)buf.bp,buf.size);
	    tmp[buf.size]=0;
	    
	    regex_replace(tmp,buf.size,"<a.*>",0x20); //killing previously <a> tag links
	    regex_replace(tmp,buf.size,"<[^>]*>",0x20);

	    char* word = strtok(tmp," ");
	    do 
		{
		word = strtok('\0', " ");
		if(word) 
		    {
		    int word_len = strlen(word);
		    word = html_ent(word,word_len);
		    if((word_len = regex_match(word,word_len,"http://[a-zA-Z0-9%/.?&-]*"))!=0)
			{
//			printf("[out] %s \n",word);
			out_link ol;
			ol.out_link  = malloc(word_len+1);
		        ol.out_link_len = word_len;
			strncpy(ol.out_link, word,ol.out_link_len);
			ol.out_link[ol.out_link_len]=0;
		    
		        ans->out_links =  realloc(ans->out_links,((ans->out_links_len+1)*sizeof(out_link)));
			ans->out_links[ans->out_links_len] = ol;

			ans->out_links_len+=1;

			}
		    }
		} while(word);
	    free(tmp);
	    tmp = NULL;
	    }
	tidyBufFree(&buf);
	}
//----------------------------------------------end parsing body ------------------------------------*/
    url_query(doc, child,ans); /* recursive */ 
    }
  }
}



int url_parsing(url_parse *ans)
{
    ans->err=0;
    
  TidyDoc tdoc;
  TidyBuffer docbuf = {0};
  TidyBuffer tidy_errbuf = {0};

  ans->err = curl_get(ans->in_link,&tdoc,&docbuf,&tidy_errbuf);

    if ( !ans->err ) 
	{
        ans->err = tidyParseBuffer(tdoc, &docbuf); /* parse the input */
          if ( ans->err >= 0 ) 
	    {
	    ans->err = tidyCleanAndRepair(tdoc); /* fix any problems */
	    if ( ans->err >= 0 ) 
		{
		ans->err = tidyRunDiagnostics(tdoc); /* load tidy error buffer */
		if ( ans->err >= 0 ) 
		    {
	    	    url_query(tdoc, tidyGetRoot(tdoc),ans); /* walk the tree */
    		    }
	        }
	    }
	tidyBufFree(&tidy_errbuf);
	tidyBufFree(&docbuf);
	tidyRelease(tdoc);
	}
  return ans->err;
}

void url_parse_init(url_parse* ans)
{
ans->meta_description = NULL;
ans->meta_description_len =0;
ans->meta_keywords=NULL;
ans->meta_keywords_len = 0;
ans->title = NULL;
ans->title_len = 0;
ans->out_links = NULL;
//ans->out_links =  malloc(sizeof(out_link));
ans->out_links_len=0;
ans->in_link=NULL;
ans->in_link_len =0;
}


void url_parse_free(url_parse * ans)
{
free(ans->meta_description);
free(ans->meta_keywords);
free(ans->title);
int i=0;
for(i=0;i!=ans->out_links_len;i++)
    free(ans->out_links[i].out_link);
}


/*
int main(void)
{
url_parse ans;
url_parse_init(&ans);
ans.in_link = "http://www.xopom.com/modules/news/article.php?storyid=3156&mode=flat&order=0&storypage=-1&Start=1068";
//http://192.168.1.6/";
//http://www.intporn.com/forums/xxx-video-mega-threads/603428-selected-ollection-xxx-video-2010-update-depositfiles-com-2.html";
//http://www.cyberciti.biz/tips/delete-leading-spaces-from-front-of-each-word.html";
//http://www.opensource.apple.com/source/tidy/tidy-2.2/tidy/src/alloc.c";
//http://ru.wikipedia.org/";
//http://www.w3schools.com/tags/tag_meta.asp";
//http://dfiles.ru/files/6329zf04m"; //!Pr0n!
url_parsing(&ans);

printf("[title] %s ;[desc] %s; [keywords] %s; [out_len] %i \n\n ",ans.title, ans.meta_description,ans.meta_keywords,ans.out_links_len);
int i;

for(i=0;i!=ans.out_links_len;i++)
    {	
    printf("[link %i] %s\n",i,ans.out_links[i].out_link);
    }	



url_parse_free(&ans);

return 0;
}
*/