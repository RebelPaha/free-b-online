#include "../header/regex.h"

int regex_replace (char *buf, int size, char *res, char rp)
{
regex_t re;
int sub, n,i,rsize=0;
regmatch_t pmatch [10];

if (regcomp (&re, res, REG_EXTENDED))
    return 0;

if (regexec (&re, buf, 10, pmatch, 0))
    return 0;

//printf("-- in_size %i --\n",strlen(buf));
//size = strlen(buf);
sub = pmatch [1].rm_so;
while(!regexec (&re, buf, 1, pmatch, 0))
    {
    n = pmatch [0].rm_eo - pmatch [0].rm_so;
    buf += pmatch [0].rm_so;

    if(rp!=0x7f)
	for(i=0;i!=n;i++)
	    buf[i]=rp;

    else
	{
	int j;

	int buf_len = 0;
	    buf_len = strlen(buf);
//printf("\n--[buf_len] %i -- --size-- %i --\n\n",buf_len, size-rsize);
	for(j=0;j<n;j++)
	    {
	    for(i=0;i!=buf_len-1;i++)
		{
		buf[i]=buf[i+1];
		}
	    buf[i]=0;
	    }
	rsize+=n;
	}

    if (sub >= 0)
	break;
    }

//printf("\n-- out_size %i --\n -- rsize %i -- \n",strlen(buf),size-rsize);
regfree (&re);
return size-rsize;
}

int regex_match(char* buf,int size,char* res)
{
regex_t re;
int sub, n;

int buf_len = 0;
buf_len = strlen(buf);
char* buf_tmp = buf;

char* tmp=malloc(buf_len+5);

regmatch_t pmatch [10];

if (regcomp (&re, res, REG_EXTENDED))
    return 0;

if (regexec (&re, buf, 10, pmatch, 0))
    return 0;

sub = pmatch [1].rm_so;

while(!regexec (&re, buf_tmp, 1, pmatch, 0))
    {
    int i;
    n = pmatch [0].rm_eo - pmatch [0].rm_so;
    buf_tmp+=pmatch[0].rm_so;
    if (strlen (buf) - n + 1 > size)
	return 0;

    for(i=0;i!=n;i++)
	tmp[i]=buf_tmp[i];
    tmp[i]=0;
    buf_tmp+=pmatch[0].rm_eo;

    if (sub >= 0)
	break;
    }

memset(buf,0,buf_len);

int tmp_len=0;
tmp_len = strlen(tmp);

strncpy(buf,tmp,tmp_len);

free(tmp);
regfree (&re);
return n;
}


