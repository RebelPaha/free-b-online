#include <stdio.h>
#include <tidy/tidy.h>
#include <tidy/buffio.h>
#include <curl/curl.h>
#include "../header/regex.h"
#include "../header/html.h"
#include "../header/g_parse.h"

#define fout stdout
#define attr_name tidyAttrName(attr)
#define attr_val tidyAttrValue(attr)
#define attr_val_len strlen(attr_val)
#define attr_name_len strlen(attr_name)


google_ans gl_ans;

void  google_query(TidyDoc doc, TidyNode tnod,google_parse* ans)
{

TidyNode child;
  for ( child = tidyGetChild(tnod); child; child = tidyGetNext(child) )
  {
    ctmbstr name = tidyNodeGetName( child );
    if ( name )
    {

///* --------- parsing title -------------
    if(tidyNodeIsH3(child))			//на всякий случай проверим класс
	{
	TidyAttr attr;
	for (attr=tidyAttrFirst(child); attr; attr=tidyAttrNext(attr) ) 
	    {
	    if((attr_name)&&(attr_val))
		{
		if((!strncasecmp(attr_name,"class",5))&&(!strncasecmp(attr_val,"r",1)))
		    {
///* -------getting title ------------
		    TidyBuffer buf;
		    tidyBufInit(&buf);
		    tidyNodeGetText(doc, child, &buf);
		    if(buf.size)
			{
    			char* title = malloc(buf.size+1);
    			strncpy(title,(char*)buf.bp,buf.size);
    			title[buf.size]=0;
    			int title_len = 0;

//			printf("[!<a>] %s\n",title);

    			title_len = regex_replace(title,buf.size,"<[^>]*>",0x7f);
    			title = html_ent(title,title_len);
			title_len = strlen(title);

			gl_ans.title = malloc(title_len+1);
			strncpy(gl_ans.title,title,title_len);
			gl_ans.title[title_len]=0;
			gl_ans.title_len = title_len;

//			printf("![title] %s\n",title);
    			free(title);
    			title = NULL;
    			}
		    tidyBufFree(&buf);
//--------end getting title ----*/
///*-------getting link ----------
		    TidyNode link_node = tidyGetChild(child);
		    TidyAttr link_attr;
		    for (link_attr=tidyAttrFirst(link_node); link_attr; link_attr=tidyAttrNext(link_attr) ) 
			{
			if((tidyAttrName(link_attr))&&(tidyAttrValue(link_attr)))
			    {
			    if(strncasecmp(tidyAttrName(link_attr),"href",4)==0)
				{
				int link_tmp_len = strlen(tidyAttrValue(link_attr));
				char* link_tmp = malloc(link_tmp_len+1);
				strncpy(link_tmp,tidyAttrValue(link_attr),link_tmp_len);
				link_tmp[link_tmp_len]=0;
				char* fub;
				char* buf;
				if((buf=(strchr(link_tmp,'=')+1))!=NULL)
				    {
				    if((fub=strchr(link_tmp,'&'))!=NULL)
					{
					int buf_len = fub-buf;
					(*(buf+buf_len))=0;
	    				buf_len = url_ent(buf,buf_len);
	    				gl_ans.link = malloc(buf_len+1);
		    			strncpy(gl_ans.link,buf,buf_len);
					gl_ans.link[buf_len]=0;
					gl_ans.link_len = buf_len-1;

					}
				    else
					{
	    				gl_ans.link = malloc(8);
		    			strncpy(gl_ans.link,"Bad URL",7);
					gl_ans.link[7]=0;
					gl_ans.link_len = 7;
					}
				    }
//				printf("![link] %s\n",buf);
				free(link_tmp);
				link_tmp = NULL;
				}
			    }
			}
//---------end getting link---------*/
		    }
		}
	    }
	}
//-----------------end parsint title ----------*/
///*---------------start parsing desc ----------
    if(tidyNodeIsSPAN(child))			//<div class=s> <span class=st>description</span>
	{
	TidyAttr attr;
	for (attr=tidyAttrFirst(child); attr; attr=tidyAttrNext(attr) ) 
	    {
	    if((attr_name)&&(attr_val))
		{
		if((!strncasecmp(attr_name,"class",5))&&(!strncasecmp(attr_val,"st",2)))
		    {
		    TidyBuffer buf;
		    tidyBufInit(&buf);
		    tidyNodeGetText(doc, child, &buf);
		    if(buf.size)
			{
    			char* tmp = malloc(buf.size+1);
    			strncpy(tmp,(char*)buf.bp,buf.size);
    			tmp[buf.size]=0;
    			int tmp_len = 0;
    			tmp_len = regex_replace(tmp,buf.size,"<[^>]*>",0x7f);
    			tmp = html_ent(tmp,tmp_len);
			tmp_len = strlen(tmp);

			gl_ans.description = malloc(tmp_len+1);
			strncpy(gl_ans.description,tmp,tmp_len);
			gl_ans.description[tmp_len]=0;
			gl_ans.description_len = tmp_len;

			ans->gans =  realloc(ans->gans,((ans->gans_len+1)*sizeof(google_ans)));		
			ans->gans[ans->gans_len] = gl_ans;
			ans->gans_len++;

//			printf("![desc] %s\n",tmp);
    			free(tmp);
    			tmp = NULL;
    			}
		    tidyBufFree(&buf);
		    }
		}
	    }
	}

//-----------------end parsing desc+link -----------*/
    google_query(doc, child,ans);
    }
  }
}



int google_parsing(google_parse *ans)
{
    ans->err=0;
    TidyDoc tdoc;
    TidyBuffer docbuf = {0};
    TidyBuffer tidy_errbuf = {0};
    ans->err = curl_get(ans->in_url,&tdoc,&docbuf,&tidy_errbuf);

    if ( !ans->err ) 
	{
	ans->err = tidyParseBuffer(tdoc, &docbuf); 
        if ( ans->err >= 0 ) 
	    {
    	    ans->err = tidyCleanAndRepair(tdoc); /* fix any problems */
    	    if ( ans->err >= 0 ) 
		{
        	ans->err = tidyRunDiagnostics(tdoc); /* load tidy error buffer */
        	if ( ans->err >= 0 ) 
		    {
    		    google_query(tdoc, tidyGetRoot(tdoc),ans); /* walk the tree */
        	    }
    		}
    	    }
	}
    tidyBufFree(&tidy_errbuf);
    tidyBufFree(&docbuf);
    tidyRelease(tdoc);
  return ans->err;
}

void google_parse_init(google_parse* ans)
{
ans->gans = NULL;
ans->gans_len=0;
ans->in_url=NULL;
ans->in_url_len =0;
}


void google_parse_free(google_parse * ans)
{
int i=0;
for(i=0;i!=ans->gans_len;i++)
    {
    free(ans->gans[i].title);
    free(ans->gans[i].description);
    free(ans->gans[i].link);
    }
}


/*
int main(void)
{
google_parse ans;
google_parse_init(&ans);
ans.in_url = "https://www.google.com.ua/search?q=intext:\"http://rapidshare.com/files\"+basic+bioreactor+design";
//https://www.google.com.ua/search?q=allintext:\"http://depositfiles.com/files/\"+files+microtype+pro";//&start=10"; //there are error in curl+ssl

google_parsing(&ans);

int i;
for(i=0;i!=ans.gans_len;i++)
    {
    printf("[title %i] %s\n",i,ans.gans[i].title);
    printf("[link %i] %s\n",i,ans.gans[i].link);
    printf("[desc %i] %s\n",i,ans.gans[i].description);
    }

google_parse_free(&ans);
return 0;
}
*/

