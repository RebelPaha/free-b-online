#include <stdio.h>
#include <tidy/tidy.h>
#include <tidy/buffio.h>
#include <curl/curl.h>

#include "../header/regex.h"
#include "../header/html.h"
#include "../header/fhparse.h"

#define fout stdout
//fhost_parse ans;

void  fl_host_query(TidyDoc doc, TidyNode tnod,fhost_parse* ans)
{
TidyNode child;
  for ( child = tidyGetChild(tnod); child; child = tidyGetNext(child) )
  {
    ctmbstr name = tidyNodeGetName( child );
    if ( name )
    {
    if(!strncmp(name,"title",4))
        {
	TidyBuffer buf;
	tidyBufInit(&buf);
        tidyNodeGetText(doc, child, &buf);
	if(buf.size)
	    {
	    char* tmp = malloc(buf.size+1);
	    strncpy(tmp,(char*)buf.bp,buf.size);
	    tmp[buf.size]=0;
	    regex_replace(tmp,buf.size,"<[^>]*>",0x7f);
	    int tmp_len = 0;
	   tmp_len = strlen(tmp);
	    //-----------------
	    ans->fh_title = malloc(tmp_len);
//	    ans->fh_title = realloc(ans->fh_title,tmp_len);
	    strncpy(ans->fh_title,tmp,tmp_len);
	    ans->fh_title[tmp_len-1]=0;
	    ans->fh_title_len = tmp_len;
	    ///
//	    fprintf(stdout,"[title] %s;",tmp);
	    free(tmp);
	    tmp = NULL;
	    }
	tidyBufFree(&buf);
        }
    TidyAttr attr;
    if(!strncmp(name,"div",3))
	{
	for (attr=tidyAttrFirst(child); attr; attr=tidyAttrNext(attr) ) 
	    {
	    if((tidyAttrName(attr))&&(tidyAttrValue(attr)))
		{
		if(!strncmp(tidyAttrName(attr),"class",5))
		    {
		    if(!strncmp(tidyAttrValue(attr),"info",4))//<- deposit
			{
			TidyNode info;
			  for (info = tidyGetChild(child); info; info = tidyGetNext(info) )
			    {
			    name = tidyNodeGetName(info);
			    if(name)
				{
			        //extract filename
				if(!strncmp(name,"script",6))
				    {
				    TidyBuffer buf;
				    tidyBufInit(&buf);
				    tidyNodeGetText(doc, info, &buf);
				    if(buf.size)
					{
					char* tmp = malloc(buf.size);
					strncpy(tmp,(char*)buf.bp,buf.size);
					tmp[buf.size-1]=0;
					regex_replace(tmp,buf.size,"<.*\\(",0x7f);
					if(regex_match(tmp,buf.size,"'.*'"))
					    {
					    int tmp_len = 0;
					    tmp_len = strlen(tmp);
					    tmp[tmp_len-1]=0;
					    tmp[0]=0x20;
//					    printf("[text] %s\n",tmp);
					    tmp_len = url_ent(tmp,tmp_len-2);
					    if((tmp_len=regex_match(tmp,tmp_len,"title=\".*\""))!=0)
						if((tmp_len=regex_match(tmp,tmp_len,"\".*\""))!=0)
						    {
						    char* file_ext ;
						    char* f_fname = malloc(tmp_len+1);
						    tmp[0]=0x20;
						    tmp[tmp_len-1]=0;

						    //-------------
						    ans->filename = malloc(tmp_len+1);
						    strncpy(ans->filename,tmp,tmp_len);
						    ans->filename_len = tmp_len;
						    ans->filename[tmp_len] = 0;
						    //*/

						    file_ext = strchr(tmp,'.');
						    int file_ext_len = strlen(file_ext);


						    //-----------    
						    ans->ext_filename = malloc(file_ext_len+1);
						    strncpy(ans->ext_filename,file_ext,file_ext_len);
						    ans->ext_filename_len = file_ext_len;
						    ans->ext_filename[file_ext_len]=0;

						    int f_fname_len = strcspn(tmp, ".");
						    strncpy(f_fname,tmp,f_fname_len);
						    f_fname[f_fname_len]=0;
						    regex_replace(f_fname,f_fname_len,"[^0-9a-zA-Z]",0x7f);
						    f_fname_len=strlen(f_fname);

						    //-----------    
						    ans->filtered_filename = malloc(f_fname_len+1);						    
						    strncpy(ans->filtered_filename,f_fname,f_fname_len);
						    ans->filtered_filename_len = f_fname_len;
						    ans->filtered_filename[f_fname_len]=0;
						            

						    //fprintf(fout,"[file_name] %s;",tmp);
						    //fprintf(fout,"[filtered_filename] %s;",f_fname);
						    //fprintf(fout,"[extension_filename] %s;",file_ext);
						    free(f_fname);
						    }
					    }
					free(tmp);
					tmp=NULL;
					}
				    tidyBufFree(&buf);
				    }
	    			//extract size
				if(!strncmp(name,"span",4))
			    	    {
				    TidyNode filesize = tidyGetChild(info);
				    if(!tidyNodeGetName(filesize))
					filesize = tidyGetNext(filesize);

				    TidyBuffer buf;
				    tidyBufInit(&buf);
				    tidyNodeGetText(doc, filesize, &buf);
				    if(buf.size)
				        {
					int tmp_len=0;
					char* tmp = malloc(buf.size+1);
					strncpy(tmp,(char*)buf.bp,buf.size);
					tmp[buf.size]=0;
					regex_replace(tmp,buf.size,"<[^>]*>",0x7f);
					tmp_len=strlen(tmp);	//killing last \n
					regex_replace(tmp,tmp_len,"&[a-z]{0,4};",0x7f);
					tmp_len=strlen(tmp);
					tmp[tmp_len-1]=0;

					
					ans->filesize = malloc(tmp_len+1);
					strncpy(ans->filesize,tmp,tmp_len);
					ans->filesize_len = tmp_len;
					ans->filesize[tmp_len]=0;
				    
					//fprintf(fout,"[size] %s;",tmp);
				        free(tmp);
					tmp = NULL;
				        }
				    tidyBufFree(&buf);
				    }
			    	}
			    }
			}
		    }
		}
	    }
	}
    }
    fl_host_query(doc, child,ans); /* recursive */ 
  }
}


int query_filehost(fhost_parse *ans)
{
    ans->err=0;

  TidyDoc tdoc;
  TidyBuffer docbuf = {0};
  TidyBuffer tidy_errbuf = {0};

    ans->err = curl_get(ans->in_link,&tdoc,&docbuf,&tidy_errbuf);

    if ( !ans->err ) {
      ans->err = tidyParseBuffer(tdoc, &docbuf); /* parse the input */
      if ( ans->err >= 0 ) {
        ans->err = tidyCleanAndRepair(tdoc); /* fix any problems */
        if ( ans->err >= 0 ) {
          ans->err = tidyRunDiagnostics(tdoc); /* load tidy error buffer */
          if ( ans->err >= 0 ) {
            fl_host_query(tdoc, tidyGetRoot(tdoc),ans); /* walk the tree */
          }
        }
      }
    }

    /* clean-up */
    tidyBufFree(&docbuf);
    tidyBufFree(&tidy_errbuf);
    tidyRelease(tdoc);
  return ans->err;
}

void fhost_parse_init(fhost_parse* ans)
{
ans->filename = NULL;
ans->filename_len =0;
ans->filtered_filename=NULL;
ans->filtered_filename_len = 0;
ans->ext_filename = NULL;
ans->ext_filename_len = 0;
ans->filesize = NULL;
ans->filesize_len =0;
ans->err=0;
ans->in_link=NULL;
ans->in_link_len =0;
}


void free_query_filehost(fhost_parse * ans)
{
free(ans->filename);
free(ans->filtered_filename);
free(ans->ext_filename);
free(ans->filesize);
}


/*
int main(void)
{
fhost_parse ans;
fhost_parse_init(&ans);
//ans.in_link = "http://dfiles.ru/files/6329zf04m"; //!Pr0n!
ans.in_link = "http://depositfiles.com/files/4317746";

query_filehost(&ans);

printf("[filename] %s ;[filtered_name] %s; [ext] %s; [filesize] %s\n\n ",ans.filename, ans.filtered_filename,ans.ext_filename,ans.filesize);

free_query_filehost(&ans);

return 0;
}
*/

