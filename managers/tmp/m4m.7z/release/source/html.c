#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <curl/curl.h>
#include <tidy/tidy.h>
#include <tidy/buffio.h>
#include "../header/html.h"

// curl write callback, to fill tidy's input buffer...  
uint write_cb(char *in, uint size, uint nmemb, TidyBuffer *out)
{
  uint r;
  r = size * nmemb;
  tidyBufAppend( out, in, r );
  return(r);
};


int url_ent(char* url, int url_len)
{
int i=0,j=0;
if((url_len)&&(url))
    {
    char* tmp = malloc(url_len);
    for(i=0;i<url_len;i++)
    {
    if(url[i]=='%')
        {
        if(url[i+1]=='u')
        {
        i+=3;	
        if(url[i]=='0')
	{
	i++;
	//tmp[j]=0;
	if(url[i]<='9')
	    {
    	    tmp[j]=(url[i]-'0')*0x10;
	    }
	else
	    {
	    if((url[i]>='A') || (url[i]<'G'))
    	    {
    	    tmp[j]=url[i]-0x37;
    	    }
	    else
    	    if((url[i]>='g') || (url[i]<'g'))
	        {
	        tmp[j]=url[i]-0x57;
	        }
	    }
	if(url[i+1]<='9')
	    {
    	    tmp[j]+=url[i+1]-'0';
	    }
	else
	    if((url[i+1]>='A') || (url[i+1]<'G'))
    	    tmp[j]+=url[i+1]-0x37;
	else
    	    if((url[i+1]>='a')||(url[i+1]<'g'))
	    tmp[j]+=url[i+1]-0x57;
	i++;
        j++;
	}
        }
    else
        {
        if(((url[i+1]>='0')&&(url[i+1]<='9'))||((url[i+1]>='A') || (url[i+1]<'G'))||((url[i+1]>='a')||(url[i+1]<'g')))
	    {
	    i++;
	    //tmp[j]=0;
	    if(url[i]<='9')
		{
    		tmp[j]=(url[i]-'0')*0x10;
		}
	    else
		{
		if((url[i]>='A') || (url[i]<'G'))
    		    {
    		    tmp[j]=url[i]-0x37;
    		    }
		else
    		    if((url[i]>='g') || (url[i]<'g'))
	    		{
	    		tmp[j]=url[i]-0x57;
	    		}
		}
	    if(url[i+1]<='9')
		{
    		tmp[j]+=url[i+1]-'0';
		}
	    else
		if((url[i+1]>='A') || (url[i+1]<'G'))
    		    tmp[j]+=url[i+1]-0x37;
		else
    		    if((url[i+1]>='a')||(url[i+1]<'g'))
			tmp[j]+=url[i+1]-0x57;
	    i++;
	    j++;
	    }
        }
        }
    else
    {
    tmp[j]=url[i];
    j++;
    }
    }
    memset(url,0,url_len);
    strncpy(url,tmp,j);
    free(tmp);
    }
return j;
}



char* html_ent(char* buf,int buf_len)
{
//buf_len = strlen(buf);
char* tmp = malloc(buf_len);
int i,z=0;
//memset(tmp,0,strlen(tmp));
if(buf_len)
{

for(i=0;i<buf_len-1;i++)
    {
    if(buf[i]=='&')
        {
        i++;
        if(buf[i]=='#')
            {
            i++;
            if((buf[i]>='0')&&(buf[i]<='9'))
                {
    if((buf[i+3]>='0')&&(buf[i+3]<='9'))		//<- if unicode symbol >255 ex &#1575;
    	{
    	tmp[z]='U';
        if((buf[i+4]>='0')&&(buf[i+4]<='9'))
    	    i+=5;
        else
            i+=4;
    	}
                else
                    {
        if((buf[i+2]>='0')&&(buf[i+2]<='9'))
                    {
                    tmp[z]=
                        (
                        ((buf[i]-'0')*100)
                        +((buf[i+1]-'0')*10)
                        +(buf[i+2]-'0')
                        );
                    i+=3;
                    }
        else
        {
    	tmp[z]=
        	    (
        	    ((buf[i]-'0')*10)
        	    +(buf[i+1]-'0')
        	    );
    	    i+=2;
        }
                    }
                z++;
                }
        else
    {
    i--;
    tmp[z]=buf[i];
        z++;
    }
            }
    else
        {
        //i--;
        if(!strncmp(buf+i,"lt",2))
        {
        tmp[z]='<';
        i+=3;
        }
        else
    if(!strncmp(buf+i,"gt",2))
            {
            tmp[z]='>';
            i+=3;
            }
        else
            tmp[z]=buf[i];
        i--;
        z++;
        }
        }
    else
        {
        tmp[z]=buf[i];
        z++;
        }
    }

tmp[z]=0;
int tmp_len =0;
tmp_len = strlen(tmp);
//buf_len=strlen(buf);
memset(buf,0,buf_len);
i=0;
while(i<tmp_len)
    {
    if((unsigned char)tmp[i]<0x20)
        {
    int symb_cnt=0;
    for(symb_cnt=i;symb_cnt<tmp_len-1;symb_cnt++)
        {
        tmp[symb_cnt]=tmp[symb_cnt+1];
        }
        tmp[symb_cnt]=0;
    tmp_len--;
        }
    else
    i++;

    }
if(z>tmp_len-1)
    strncpy(buf,tmp,tmp_len);
else
    {
    strncpy(buf,tmp,buf_len);
    }

}
free(tmp);
tmp=NULL;
return buf;
}

int curl_get(char* in_link,TidyDoc *tdoc,TidyBuffer *docbuf, TidyBuffer *tidy_errbuf)
{
    int err=0;
  CURL *curl;
  char curl_errbuf[CURL_ERROR_SIZE];
  
  curl = curl_easy_init();
  curl_easy_setopt(curl, CURLOPT_URL, in_link);
  curl_easy_setopt(curl, CURLOPT_ERRORBUFFER, curl_errbuf);
  curl_easy_setopt(curl, CURLOPT_NOPROGRESS, yes);
  curl_easy_setopt(curl, CURLOPT_VERBOSE, no);
  curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, yes);
  curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_cb);
   curl_easy_setopt(curl, CURLOPT_COOKIEFILE, "cookies");

  *tdoc = tidyCreate();
  tidyOptSetBool(*tdoc, TidyForceOutput, yes); /* try harder */
  tidySetErrorBuffer( *tdoc, tidy_errbuf );
  tidyOptSetInt(*tdoc, TidyWrapLen, 4096);
  tidyBufInit(docbuf);

  curl_easy_setopt(curl, CURLOPT_WRITEDATA, docbuf);
  err=curl_easy_perform(curl);
  curl_easy_cleanup(curl);
  if(err)
      fprintf(stderr, "[link]%s \n[err]%s\n",in_link, curl_errbuf);

  return err;
}